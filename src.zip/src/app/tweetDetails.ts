import {UserDetails} from './userDetails';

export class TweetDetails {
  id: string;
  user: UserDetails;
}

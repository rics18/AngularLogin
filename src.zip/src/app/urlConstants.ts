
export class UrlConstants {
  public static GOOGLE_API = 'https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword?key=AIzaSyD8W0pWlju6wOPr3ih_aio2gNiVKHd9F8g';
  public static TWEETER_API = 'https://angular-sample-twitter.firebaseio.com/tweets.json?auth=';
}


export class User {
   email: string;
   password: string;
   returnSecureToken: boolean;
   id: string;
}
